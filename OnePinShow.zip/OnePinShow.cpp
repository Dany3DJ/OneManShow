// LED.cpp
#include "OnePinShow.h"

OPS::OPS(int Pin = 7) {
  pulsePin = Pin;
  pinMode(pulsePin, OUTPUT);

}

void OPS::Send(int selection) {

  //Keep sending unless the receiver confirmation signal is detected
  while (digitalRead(pulsePin) != HIGH) {

    //Start sending HIGH
    digitalWrite(pulsePin, HIGH);

    //Apply delay based on selection + a small offset
    delayMicroseconds((selection * dtime) + 4);

    //Start sending low for a short period
    digitalWrite(pulsePin, LOW);
    delayMicroseconds(20);
  }
}

int OPS::Receive(int type = 0) {
  int i = 0; //Generic counter
  unsigned long ontime = 0; //Counter for pulse time
  unsigned long avgTime = 0; //Counter for average time

  while (!Handshake());

  //Take a number of readings for averaging
  while (i < iterations) {

    //Read the pulse duration
    ontime = pulseIn(pulsePin, HIGH);
    avgTime += (ontime - 4);
    delayMicroseconds(50);
    i++;
  }
  //Calculate the average
  avgTime /= iterations;

  //Send the confirmation signal
  digitalWrite(pulsePin, HIGH);
  delay(10);
  digitalWrite(pulsePin, LOW);

  //Return the number if type=0 or the raw value if type=1
  if (type == 0) {
    avgTime /= dtime;
  }
  return avgTime;
}
void OPS::Send(char selection) {

  while (!Handshake());

  //Keep sending unless the receiver confirmation signal is detected
  while (digitalRead(pulsePin) != HIGH) {

    //Start sending HIGH
    digitalWrite(pulsePin, HIGH);

    //Apply delay based on selection + a small offset
    delayMicroseconds(((byte)selection * dtime) + 5);

    //Start sending low for a short period
    digitalWrite(pulsePin, LOW);
    delayMicroseconds(10);
  }

  while (digitalRead(pulsePin) == HIGH) {

  }
  digitalWrite(pulsePin, HIGH);
}
char OPS::ReceiveC() {
  int i = 0; //Generic counter
  unsigned long ontime = 0; //Counter for pulse time
  unsigned long avgTime = 0; //Counter for average time

  while (!Handshake());

  //Take a number of readings for averaging
  while (i < iterations) {

    //Read the pulse duration
    ontime = pulseIn(pulsePin, HIGH);
    avgTime += (ontime - 4);
    delayMicroseconds(50);
    i++;
  }
  //Calculate the average
  avgTime /= iterations;

  //Send the confirmation signal
  digitalWrite(pulsePin, HIGH);
  delay(10);
  digitalWrite(pulsePin, LOW);

  //Return the number if type=0 or the raw value if type=1
  return char(avgTime /= dtime);

}
bool OPS::Handshake() {
  digitalWrite(pulsePin, HIGH);
  while (digitalRead(pulsePin) == LOW) {
  }
  digitalWrite(pulsePin, LOW);
  return 1;
}
void OPS::GetMSG(int arr[], int Size, int type = 0) {
  for (int i = 0; i < Size; i += 1) {
    arr[i] = this->Receive(type);
  }
}
String OPS::GetMSG(void) {
  Serial.begin(9600);
  char x;
  String out = "";
  int i = 0;
  do {
    x = this->ReceiveC();
    //Serial.print(x);
    out += x;
  }
  while (x != '\0');
  //Serial.print(out);
  return out;

}
void OPS::SendMSG(int arr[], int Size){
  for (int i=0; i<Size; i+=1){
    delay((Size/10));
    this->Send(arr[i]);
  }
}
void OPS::SendMSG(String arr){
  int Size=arr.length();
  int i=0;
  this->Send('\7');
  while(arr[i]!='\0'){
    delay((Size/10));
    this->Send(arr[i]);
    i++;
  
  }
  this->Send('\0');
}
