#ifndef OPS_h
#define OPS_h
//This library was created by Daniel Joseph in a time of need
//where there was no other solutions available
#include <Arduino.h>

class OPS {
  private:
    int pulsePin;
    int dataPin=3;
    int dtime=10;
    int iterations=4;
    
  public:
    OPS(int Pin=7);
    bool Handshake();
    void Send(int selection);
    void Send(char selection);
    int Receive(int type=0);
    char ReceiveC();
    void GetMSG(int arr[],int Size, int type=0);
    String GetMSG(void);
    void SendMSG(int arr[], int Size);
    void SendMSG(String arr);
};

#endif
